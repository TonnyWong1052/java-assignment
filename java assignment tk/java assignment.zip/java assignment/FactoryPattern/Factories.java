package FactoryPattern;


public interface Factories {

    abstract public void create();
}
