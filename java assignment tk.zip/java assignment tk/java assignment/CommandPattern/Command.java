package CommandPattern;

public interface Command {

	abstract public void execute();

	abstract public void printDetail();

}
